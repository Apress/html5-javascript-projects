var base= 
		[41.04796,-73.70539,"Purchase College/SUNY"];

var zoomlevel = 13;
var precontent = [
   [41.19991,-73.72353,"Esther at home","pictureaudio","estherT","esther.jpg"],
   [41.05079,-73.70448,"Lego robot ","video","maze"],
   [40.68992,-74.04460,"Fire works ","video","sfire3"],
   [41.8442,-89.480,"Aviva in Dixon","picture","avivadixon.jpg"]
   ];

var maxdistance = 5; 

