<?php
global $DBname, $link;
$host = '               ';
$user="           ";
$password="              ";
$DBname="                ";
$link=mysql_connect($host,$user,$password);
mysql_select_db($DBname,$link);
?>